# Class Materials

[CSCI 127 Joy and Beauty of Data](https://montanajim.github.io/csci127/intro.html)

[CSCI 121 JAVA II](https://montanajim.github.io/csci121/intro.html)

[CSCI 132 Basic Data Structures](https://montanajim.github.io/csci132/intro.html)

[CSCI 210 Web Programming](https://montanajim.github.io/CSCI210/intro.html)

[CSCI 232 Intermediate Algorithms](https://montanajim.github.io/CSCI232/intro.html)

[CSCI 238 Mobile Apps](https://montanajim.github.io/csci238/intro.html)

[CSCI 240 Databases & SQL](https://montanajim.github.io/csci240/intro.html)



```{tableofcontents}
[CSCI Basic Data Structures](https://montanajim.github.io/csci132/intro.html)
[CSCI 238 Mobile Apps](https://montanajim.github.io/csci238/intro.html)
```






# Class Notes For CSCI 238

These are the class notes for CSCI 238 Mobile Applications.  This course focuses on Mobile Apps using the Flutter Suite.  The developer only has to write the code once and the flutter suite can allow it to be deployed on Android, IOS, websites, etc.

```{tableofcontents}
```

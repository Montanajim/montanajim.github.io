# Welcome to CSCI 127 Joy and Beauty of Data

These are the class notes for CSCI 127 Joy and Beauty of data. This course focuses on core programming techniques applicable to all languages along with specific libraries and techniques only to Python.



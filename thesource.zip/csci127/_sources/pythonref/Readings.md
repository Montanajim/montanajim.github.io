# Readings

These are reading links to online textbooks and other material.

## The Basics

[Chapter 1 - thinkcspy](https://runestone.academy/ns/books/published/thinkcspy/GeneralIntro/toctree.html)

[Chapter 2 - thinkcspy](https://runestone.academy/runestone/books/published/thinkcspy/SimplePythonData/toctree.html)

[Top 10 Programming Languages to Learn in 2022](https://www.geeksforgeeks.org/top-10-programming-languages-to-learn-in-2022/)



## Functions

[Chapter 5 - Modules - thinkcspy](https://runestone.academy/ns/books/published/thinkcspy/PythonModules/toctree.html)

[Chapter 6 - Functions - thinkcspy](https://runestone.academy/ns/books/published/thinkcspy/Functions/toctree.html)



---

End Of Topic


# Data Structures and Algorithms



## Textbooks and Online Sources







|                             Book                             |                       Book Information                       |
| :----------------------------------------------------------: | :----------------------------------------------------------: |
| ![Data Strucures](https://images-na.ssl-images-amazon.com/images/I/51NoqhM4r9L._SX407_BO1,204,203,200_.jpg) | [Data Structures and Algorithms in Java](https://www.amazon.com/Data-Structures-Algorithms-Java-2nd/dp/0672324539/ref=sr_1_1?crid=M8ANR5REE3Y8&keywords=robert+lafore&qid=1655244033&sprefix=robert+lafore%2Caps%2C126&sr=8-1) <br>Second Edition<br>Robert Lafore |
| ![Data Structrues & Alogrithms](https://images-na.ssl-images-amazon.com/images/I/61cFhkf7NCL._SX405_BO1,204,203,200_.jpg) | [Data Structures and Algorithms in Java 6th Edition](https://www.amazon.com/Data-Structures-Algorithms-Michael-Goodrich/dp/1118771338/ref=sr_1_6?keywords=data+structures+and+algorithms&qid=1655244532&s=books&sprefix=datastructures+and+%2Cstripbooks%2C130&sr=1-6)<br>Micahel T. Goodrich |
| ![Algorithms](https://images-na.ssl-images-amazon.com/images/I/41a4YqyJv4S._SX400_BO1,204,203,200_.jpg) | [Algorithms (4th Edition) 4th Edition<br/>by Robert Sedgewick and Kevin Wayne](https://www.amazon.com/gp/product/032157351X/ref=as_li_qf_sp_asin_il_tl?ie=UTF8&tag=algs4-20&linkCode=as2&camp=1789&creative=9325&creativeASIN=032157351X) |
| ![Open Data Structures](https://opendatastructures.org/ods-java/img41.png) |   [Open Data Structures](https://opendatastructures.org/)    |



---

End Of Topic




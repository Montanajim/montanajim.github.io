Welcome to CSCI 132
============================

This class introduces the JAVA language and basic data structures. Some of the basic data structures include arrays, linked lists, and some sorting.



> “Always code as if the guy who ends up maintaining your code will be a violent psychopath who knows where you live” - John Woods



---




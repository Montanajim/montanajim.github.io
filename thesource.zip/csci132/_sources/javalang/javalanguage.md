# Java Language



An introduction to the Java Language

> Java is C++ without the guns, clubs and knives.
*James Gosling*

>C makes it easy to shoot yourself in the foot. C++ makes it harder.  But when you do, it blows your whole leg off.
*Bjarne Stroustrup*



---


# Reference Reading



## Additional supplemental topics.

Articles you find helpful

[Unable To Run .JAR Files in Windows 10 / 11 ? Here’s the Solution](https://thegeekpage.com/unable-to-run-jar-files-in-windows-10-heres-the-solution/)




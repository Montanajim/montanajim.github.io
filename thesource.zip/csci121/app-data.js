
(function() {
  var sizzle = $(document).data('sizzle');

  sizzle.app_data = JSON.parse('{"glossary": {"document": null, "terms": {}}, "custom_data": {}}');
})();
